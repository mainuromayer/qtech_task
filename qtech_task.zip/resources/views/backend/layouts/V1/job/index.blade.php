@extends('backend.app')

@section('title', 'Jobs')

@push('styles')
    <link href="{{asset('backend/libs/datatables.net-bs5/css/dataTables.bootstrap5.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('backend/libs/datatables.net-buttons-bs5/css/buttons.bootstrap5.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('backend/libs/datatables.net-keytable-bs5/css/keyTable.bootstrap5.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('backend/libs/datatables.net-responsive-bs5/css/responsive.bootstrap5.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('backend/libs/datatables.net-select-bs5/css/select.bootstrap5.min.css')}}" rel="stylesheet" type="text/css" />
@endpush

@section('content')
<div class="container-fluid">
    <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
        <div class="flex-grow-1">
            <h4 class="fs-18 fw-semibold m-0">Jobs</h4>
        </div>
        <div class="text-end">
            <ol class="breadcrumb m-0 py-0">
                <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">Dashboard</a></li>
                <li class="breadcrumb-item active">Jobs</li>
            </ol>
        </div>
    </div>

    @if(session('success'))
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: "{{ session('success') }}",
            timer: 2000,
            showConfirmButton: false
        });
    </script>
    @endif

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="card-title mb-0">Job List</h5>
                    <a href="{{ route('job.create') }}" class="btn btn-primary">
                        Add New
                    </a>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="datatable" class="table table-bordered w-100">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Category</th>
                                    <th>Type</th>
                                    <th>Location</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
        }
    });

    if (!$.fn.DataTable.isDataTable('#datatable')) {
        $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            responsive: true,
            autoWidth: false,
            ajax: "{{ route('job.index') }}",
            order: [[0, 'desc']],
            columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
                { data: 'title', name: 'title', orderable: true, searchable: true },
                { data: 'category', name: 'category.title', orderable: true, searchable: true },
                { data: 'job_type', name: 'job_type', orderable: true, searchable: true },
                { data: 'location', name: 'location', orderable: true, searchable: true },
                { data: 'status', name: 'status', orderable: true, searchable: true },
                { data: 'action', name: 'action', orderable: false, searchable: false }
            ]
        });
    }
});

// Status Change
function showStatusChangeAlert(id) {
    event.preventDefault();

    Swal.fire({
        title: 'Are you sure?',
        text: 'You want to update the status?',
        icon: 'info',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No',
    }).then((result) => {
        if (result.isConfirmed) {
            let url = '{{ route("job.status", ":id") }}';
            $.get(url.replace(':id', id), function(resp) {
                $('#datatable').DataTable().ajax.reload();
                Swal.fire({
                    position: "center",
                    icon: "success",
                    title: resp.message,
                    showConfirmButton: false,
                    timer: 1500
                });
            });
        } else {
            let checkbox = document.querySelector('#flexSwitch' + id);
            checkbox.checked = !checkbox.checked;
        }
    });
}

// Delete Job
function showDeleteConfirm(id) {
    event.preventDefault();
    Swal.fire({
        title: 'Are you sure you want to delete this job?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!',
    }).then((result) => {
        if (result.isConfirmed) {
            let url = '{{ route("job.destroy", ":id") }}';
            $.ajax({
                type: "DELETE",
                url: url.replace(':id', id),
                headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
                success: function(resp) {
                    $('#datatable').DataTable().ajax.reload();
                    Swal.fire({
                        position: "center",
                        icon: "success",
                        title: resp.message,
                        showConfirmButton: false,
                        timer: 1500
                    });
                }
            });
        }
    });
}
</script>

<!-- DataTables JS -->
<script src="{{asset('backend/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-bs5/js/dataTables.bootstrap5.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-buttons/js/buttons.colVis.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-buttons/js/buttons.flash.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-buttons/js/buttons.html5.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-buttons/js/buttons.print.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-buttons-bs5/js/buttons.bootstrap5.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-keytable-bs5/js/keyTable.bootstrap5.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-responsive-bs5/js/responsive.bootstrap5.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-select/js/dataTables.select.min.js')}}"></script>
<script src="{{asset('backend/libs/datatables.net-select-bs5/js/select.bootstrap5.min.js')}}"></script>
@endpush
