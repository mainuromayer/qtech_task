<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8" />
    <title>404 not found!</title>
{{--    <meta name="viewport" content="width=device-width, initial-scale=1.0">--}}
{{--    <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc."/>--}}
{{--    <meta name="author" content="Zoyothemes"/>--}}
{{--    <meta http-equiv="X-UA-Compatible" content="IE=edge" />--}}

    <!-- App favicon -->
    <link rel="shortcut icon" href="{{asset('backend/images/favicon.ico')}}">

    <!-- App css -->
    <link href="{{asset('backend/css/app.min.css')}}" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons -->
    <link href="{{asset('backend/css/icons.min.css')}}" rel="stylesheet" type="text/css" />

    <script src="{{asset('backend/js/head.js')}}"></script>


</head>

<!-- body start -->
<body data-menu-color="light" data-sidebar="default">

<div class="maintenance-bg-image">

<!-- Begin page -->
<div class="maintenance-pages">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-xl-12 align-self-center">
                <div class="row">
                    <div class="col-md-5 mx-auto">
                        <div class="text-center">
                            <div class="mb-0">
                                <h3 class="fw-semibold text-dark text-capitalize">Oops!, Page Not Found</h3>
                                <p class="text-dark">This pages you are trying to access does not exits or has been moved. <br> Try going back to our homepage.</p>
                            </div>

                            <a class='btn btn-primary mt-3 me-1' href="{{route('dashboard')}}">Back to Home</a>

                            <div class="error-page mt-4">
                                <img src="{{asset('backend/images/svg/404-error.svg')}}" class="img-fluid" alt="coming-soon">
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END wrapper -->

<!-- Vendor -->
<script src="{{asset('backend/libs/jquery/jquery.min.js')}}"></script>
<script src="{{asset('backend/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('backend/libs/simplebar/simplebar.min.js')}}"></script>
<script src="{{asset('backend/libs/node-waves/waves.min.js')}}"></script>
<script src="{{asset('backend/libs/waypoints/lib/jquery.waypoints.min.js')}}"></script>
<script src="{{asset('backend/libs/jquery.counterup/jquery.counterup.min.js')}}"></script>
<script src="{{asset('backend/libs/feather-icons/feather.min.js')}}"></script>

<!-- App js-->
<script src="{{asset('backend/js/app.js')}}"></script>

</div>
</body>
</html>
